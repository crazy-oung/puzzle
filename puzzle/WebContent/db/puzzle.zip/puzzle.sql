-- --------------------------------------------------------
-- 호스트:                          127.0.0.1
-- 서버 버전:                        10.4.8-MariaDB - mariadb.org binary distribution
-- 서버 OS:                        Win64
-- HeidiSQL 버전:                  10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- puzzle 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `puzzle` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `puzzle`;

-- 테이블 puzzle.member 구조 내보내기
CREATE TABLE IF NOT EXISTS `member` (
  `member_id` varchar(500) NOT NULL,
  `member_pw` varchar(500) NOT NULL,
  `level` enum('Y','N') NOT NULL DEFAULT 'N',
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 테이블 데이터 puzzle.member:~2 rows (대략적) 내보내기
DELETE FROM `member`;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` (`member_id`, `member_pw`, `level`) VALUES
	('goodee', '1', 'Y'),
	('goodee1', '1', 'Y'),
	('hi', '1', 'Y'),
	('sample@goodee.co.kr', '1234', 'Y');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;

-- 테이블 puzzle.report 구조 내보내기
CREATE TABLE IF NOT EXISTS `report` (
  `report_id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` varchar(500) DEFAULT NULL,
  `report_date` datetime DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `timer` int(11) DEFAULT NULL,
  PRIMARY KEY (`report_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- 테이블 데이터 puzzle.report:~11 rows (대략적) 내보내기
DELETE FROM `report`;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
INSERT INTO `report` (`report_id`, `member_id`, `report_date`, `count`, `timer`) VALUES
	(1, 'sample@goodee.co.kr', '2019-10-16 16:37:43', 40, 15),
	(2, 'sample@goodee.co.kr', '2019-09-16 16:39:45', 52, 24),
	(3, 'sample@goodee.co.kr', '2019-10-16 16:41:51', 36, 21),
	(4, 'sample@goodee.co.kr', '2019-10-16 16:45:07', 38, 14),
	(5, 'sample@goodee.co.kr', '2019-10-16 16:47:17', 36, 15),
	(6, 'sample@goodee.co.kr', '2019-10-16 16:58:21', 36, 13),
	(7, 'sample@goodee.co.kr', '2019-10-16 17:01:31', 36, 10),
	(8, 'sample@goodee.co.kr', '2019-10-16 17:15:05', 44, 524),
	(9, 'sample@goodee.co.kr', '2019-10-16 17:16:57', 44, 18),
	(10, 'hi', '2019-10-16 17:17:55', 36, 14),
	(11, 'sample@goodee.co.kr', '2019-10-17 13:47:57', 128, 76);
/*!40000 ALTER TABLE `report` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
